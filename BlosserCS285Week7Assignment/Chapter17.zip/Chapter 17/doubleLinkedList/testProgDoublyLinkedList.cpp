//Program to test various operations on a doubly linked list
  
#include <iostream>
#include "doublyLinkedList.h"  
 
using namespace std;  

int main()
{
	cout << "See Programming Exercise 12 at the end of the chapter" << endl;

	return 0;
} 
